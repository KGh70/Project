﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Products.Data;
using Products.Models;
using System.Diagnostics;
using Products.Areas.Identity.Data;

namespace Products.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly UserManager<DashboardUser> _userManager;
        public HomeController(ApplicationDbContext context,
                           IWebHostEnvironment webHostEnvironment,
                           UserManager<DashboardUser> userManager) 
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;
            _userManager = userManager; 
        }



        public JsonResult GetData(int id)
        {
            var product = _context.Products.SingleOrDefault(p => p.Id == id);

            if (product != null)
            {
                return Json(product);
            }
            else 
            {
                return Json(null);
            }
        }

        [Route("create")]
        public IActionResult Create(Product p)
        {

            if (ModelState.IsValid)
            {
                _context.Products.Add(p);
                _context.SaveChanges();
                TempData["Add"] = "تمت الإضافة بنجاح";
                return RedirectToAction("AddNewProduct");

            }
            TempData["Add"] = "لم تتم الإضافة يرجى التأكد من صحة المدخلات";


            var products = _context.Products.ToList();
            return View("AddNewProduct", products);


        }

        public IActionResult CreateDetails(ProductDetails productDetails, IFormFile photo)
        {



            if (photo == null || photo.Length == 0)
            {
                return Content("File Not Selected");
            }

            var path = Path.Combine(_webHostEnvironment.WebRootPath, "img", photo.FileName);

            using (FileStream stream = new FileStream(path, FileMode.Create))
            {
                photo.CopyTo(stream);
                stream.Close();
            }

            productDetails.Images = photo.FileName;
            _context.ProductDetails.Add(productDetails);
            _context.SaveChanges();
            return RedirectToAction("ProductsDetails");
        }
        public IActionResult ProductsDetails()
        {
            ViewBag.Username = HttpContext.Session.GetString("userdata");

            var ProductDetails = _context.ProductDetails.Join(

                _context.Products,

                productsdetails => productsdetails.Products_Id,
                product => product.Id,

                (productsdetails, product) => new
                {
                    id = productsdetails.Id,
                    name = product.Name,
                    color = productsdetails.Color,
                    price = productsdetails.Price,
                    qty = productsdetails.Qty,
                    img = productsdetails.Images,
                }



                ).ToList();

            var prodcts = _context.Products.ToList();

            ViewBag.products = prodcts;
            ViewBag.ProductDetails = ProductDetails;
            return View();
        }


        [HttpPost]
        public IActionResult UpdateDetails(ProductDetails model, IFormFile newPhoto)
        {
            var existingDetail = _context.ProductDetails.Find(model.Id);
            if (existingDetail != null)
            {
                existingDetail.Products_Id = model.Products_Id; 
                existingDetail.Price = model.Price;
                existingDetail.Qty = model.Qty;
                existingDetail.Color = model.Color;

                // Handle photo update
                if (newPhoto != null && newPhoto.Length > 0)
                {
                    var path = Path.Combine(_webHostEnvironment.WebRootPath, "img", newPhoto.FileName);
                    using (var stream = new FileStream(path, FileMode.Create))
                    {
                        newPhoto.CopyTo(stream);
                    }
                    existingDetail.Images = newPhoto.FileName;  
                }

                _context.Update(existingDetail);
                _context.SaveChanges();
                TempData["UpdateMessage"] = "Details updated successfully.";
            }
            else
            {
                TempData["UpdateMessage"] = "Detail not found.";
            }

            return RedirectToAction("ProductsDetails");
        }


        public IActionResult DeleteDetails(int id)
        {
            var detail = _context.ProductDetails.SingleOrDefault(p => p.Id == id);
            if (detail != null)
            {
                _context.ProductDetails.Remove(detail);
                _context.SaveChanges();
                TempData["DeleteMessage"] = "تم الحذف بنجاح";
            }
            else
            {
                TempData["DeleteMessage"] = "فشل الحذف";
            }
            return RedirectToAction("ProductsDetails");
        }

        public IActionResult GetProductDetailData(int id)
        {
            var productDetail = _context.ProductDetails.Find(id);
            if (productDetail != null)
            {
                return Json(new
                {
                    id = productDetail.Id,
                    products_Id = productDetail.Products_Id,
                    price = productDetail.Price,
                    qty = productDetail.Qty,
                    color = productDetail.Color
                });
            }
            else
            {
                return Json(null);
            }
        }

        public class ProductViewModel
        {
            public Product NewProduct { get; set; }
            public IEnumerable<Product> Products { get; set; }
        }


        public IActionResult AddNewProduct()
        {
            ViewBag.Username = HttpContext.Session.GetString("userdata");
            var products = _context.Products.ToList();  
            return View(products);
        }



        [Authorize]
        public IActionResult Index()
        {
            var username = HttpContext.User.Identity.Name ?? null;  // get user data


            //CookieOptions cookie = new CookieOptions(); // create  cookie
            //cookie.Expires = DateTime.Now.AddMinutes(50); // set time long
            //Response.Cookies.Append("userdata", username, cookie); // store user data in my cookie


            HttpContext.Session.SetString("userdata", username);

            ViewBag.Username = username;

            // ViewBag.Username = Request.Cookies["userdata"]; // get user data from my cookie

            return View();
        }



        [Route("test")]
        public void Test()
        {
            Console.WriteLine("Success");
        }


        [HttpPost]
        public JsonResult Delete(int record_no)
        {
            var productdel = _context.Products.SingleOrDefault(p => p.Id == record_no);
            if (productdel != null)
            {
                _context.Products.Remove(productdel);
                _context.SaveChanges();
                TempData["del"] = true;
            }
            else
            {
                TempData["del"] = false;
            }

            return Json("Ok");
        }

        [HttpPost]
        public IActionResult Update(Product product)
        {
            if (ModelState.IsValid)
            {
                _context.Products.Update(product);
                _context.SaveChanges();
                TempData["UpdateMessage"] = "Product updated successfully.";  
                return RedirectToAction("AddNewProduct"); 
            }

            
            return View("Edit", product);
        }


        public IActionResult Edit(int id)
        {
            var product = _context.Products.Find(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }




        public IActionResult AddDemag(Damegedproducts damege)
        {

            _context.Add(damege);
            _context.SaveChanges();

            return RedirectToAction("Demag");
        }
        public IActionResult Demag()
        {   
            ViewBag.Username = HttpContext.Session.GetString("userdata");
            var products = _context.Products.ToList();

            var Productsdemage = _context.Damegedproducts.Join
                (
                     _context.Products,

                      demag => demag.ProductId,
                      products => products.Id,


                     (demag, products) => new
                     {
                         demag,
                         products
                     }

                ).Join
                (
                  _context.ProductDetails,

                  p => p.demag.ProductId,
                  c => c.Products_Id,

                  (p, c) => new
                  {
                      id = p.demag.Id,
                      name = p.products.Name,
                      color = c.Color,
                      qty = p.demag.Qty
                  }
                  ).ToList();

            Console.WriteLine($"{Productsdemage}");


            ViewBag.products = products;
            ViewBag.damage = Productsdemage;


            return View();
        }



        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        [Authorize]
        public IActionResult ViewAllUsers()
        {
            ViewBag.Username = HttpContext.Session.GetString("userdata");
            var users = _userManager.Users.ToList(); 
            return View(users);
        }

    }
}
