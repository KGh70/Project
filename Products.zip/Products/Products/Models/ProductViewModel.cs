﻿using Products.Models;

public class ProductViewModel
{
    public Product NewProduct { get; set; } = new Product(); // For creating a new product
    public IEnumerable<Product> Products { get; set; } = new List<Product>(); // For listing products
}
